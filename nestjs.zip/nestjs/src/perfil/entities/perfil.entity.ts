export class Perfil {}
